fn.diversity.partition <-
function(     # Diversity partitioning
  dat.comm,
  q.order=1){
  
  require(vegetarian)
  
  div.results<-data.frame(
    d.alpha=d(dat.comm,lev="alpha",
              wts=rowSums(dat.comm),
              q=q.order),
    d.beta=d(dat.comm,lev="beta",
             wts=rowSums(dat.comm),
             q=q.order),
    d.gamma=d(dat.comm,lev="gamma",
              wts=rowSums(dat.comm),
              q=q.order)
  )
  
  names(div.results)<-paste(names(div.results),".q",q.order,sep="")
  
  return(div.results)
}
