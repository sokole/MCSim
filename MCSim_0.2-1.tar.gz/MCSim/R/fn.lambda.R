fn.lambda <-
function(
  trait.optimum,
  niche.breadth,
  Ef,
  Ef.specificity){
  if(Ef.specificity!=0){
    integrate(f=function(e,t,niche)exp(-1 * ((e -  t)^2) / (2 * niche^2) ),
              lower=Ef-(Ef.specificity/2),
              upper=Ef+(Ef.specificity/2),
              t=trait.optimum,
              niche=niche.breadth)$value
  }else{
    exp(-1 * ((Ef -  trait.optimum)^2) / (2 * niche.breadth^2) )
  }
}
