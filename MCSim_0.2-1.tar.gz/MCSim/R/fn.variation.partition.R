fn.variation.partition <-
function(
  dat.comm,
  E,
  S,
  q.order=1){

  require(vegan)
  
  # -- remove unobserved species
  dat.comm<-dat.comm[,colSums(dat.comm)>0]
  
  # -- Variation partitioning
  S.formula<-"ALL"
  
  # -- calc dists based on CqN overlap
  if(q.order==0){
    dat.comm.dist<-vegdist(dat.comm,"bray",binary=TRUE) #same result as fn.true.dist, but vegdist is faster
  }else if(q.order==2){
    dat.comm.dist<-vegdist(dat.comm,"horn")
  }else{
    dat.comm.dist<-as.dist(fn.true.dist(d=dat.comm,q.order=q.order)) #same result as fn.true.dist, but vegdist is faster
  }
  
  # -- check for postivit eigenvalues in comm matrix
  eig.comm<-eigen(dat.comm.dist)
  eig.check<-sum(eig.comm$values[eig.comm$values>0])>0
  
  # -- select significant PCNM vars
  fn.sig.dbRDA<-function(X=S[,1],Y=dat.comm.dist){
    require(vegan)
    mod.anova<-anova(capscale(Y~X,na.action="na.omit"))
    return(mod.anova["Model","Pr(>F)"])
  }
  
  if(eig.check){
    pcnm.pvals<-apply(X=S,
                      MARGIN=2,
                      FUN=fn.sig.dbRDA,
                      Y=dat.comm.dist)
    
    pcnm.pvals[is.na(pcnm.pvals)]<-1 #set NAs as non-significant
    
    pcnm.sig.list<-names(pcnm.pvals[pcnm.pvals<=0.05])
    if(length(pcnm.sig.list)==0) pcnm.sig.list<-names(pcnm.pvals[pcnm.pvals==min(pcnm.pvals)])
    
    if(nrow(S)>length(pcnm.sig.list)) S.formula<-paste(pcnm.sig.list,collapse="+")
    
    if(length(pcnm.sig.list)>1){
      S<-S[,pcnm.sig.list]
    }else{
      S<-data.frame(x=S[,pcnm.sig.list])
      names(S)<-pcnm.sig.list
    }
    
    # -- calculate dbRDA models
    mod.ab<-capscale(dat.comm.dist~.,data=E,na.action="na.omit")
    mod.bc<-capscale(dat.comm.dist~.,data=S,na.action="na.omit")
    mod.abc<-capscale(dat.comm.dist~.,data=cbind(E,S),na.action="na.omit")
    
    ab<-RsquareAdj(mod.ab)$adj.r.squared
    #   p.ab<-anova(mod.ab)["Model","Pr(>F)"]
    bc<-RsquareAdj(mod.bc)$adj.r.squared
    #   p.bc<-anova(mod.bc)["Model","Pr(>F)"]
    abc<-RsquareAdj(mod.abc)$adj.r.squared
    #   p.abc<-anova(mod.abc)["Model","Pr(>F)"]
    
    a<-abc-bc
    c<-abc-ab
    b<-ab+bc-abc
    d<-1-abc
    
    var.part.results<-data.frame(a=a,b=b,c=c,d=d,
                                 E=ab,
                                 S=bc,
                                 ES=abc,
                                 S.vars=S.formula)
  }else{
    var.part.results<-data.frame(a=NA,b=NA,c=NA,d=NA,
                                 E=NA,
                                 S=NA,
                                 ES=NA,
                                 S.vars=NA)
  }
  
  return(var.part.results)
}
