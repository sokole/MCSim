fisher.ecosystem <-
function(N, S, nmax, alpha = 2, c = 0){
  x <- N/(N + alpha)
  j <- 1:nmax
  jj <- rpois(n = nmax, lambda = alpha * x^j/(j + c))
  out <- as.count(rep(1:sum(jj), rep(j, jj)))
  names(out) <- paste("sp", names(out), sep = ".")
  return(out)
}
