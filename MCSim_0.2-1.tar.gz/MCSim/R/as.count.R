as.count <-
function (a, add = ""){
  if (is.count(a)) {
    out <- a
  }
  else if (is.data.frame(a)) {
    if (nrow(a) != 1) {
      stop("data frame supplied: must have only one row")
    }
    out <- as.numeric(a)
    names(out) <- colnames(a)
    out <- count(out[out > 0])
  }
  else if (is.table(a)) {
    out <- count(a)
  }
  else {
    out <- count(table(a))
  }
  if (length(out) > 0) {
    names(out) <- paste(add, names(out), sep = "")
  }
  return(out)
}
