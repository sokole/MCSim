fn.lottery.recruit <-
function(
  vect.recruitment.weights,
  vect.taxa.list,   # -- recruitment pool with weights
  scalar.JL  
){
  # -- function to recruit from a source pool, given site carrying capacities and a recruitment pool
  dat.abund<-table(as.character(
    sample(x=vect.taxa.list,                            
           size=scalar.JL,           
           prob=vect.recruitment.weights,
           replace=TRUE)))[vect.taxa.list]
  names(dat.abund)<-vect.taxa.list
  dat.abund[is.na(dat.abund)]<-0
  return(dat.abund) 
}
