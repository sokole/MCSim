fn.metaSIM<-function(
  scenario.ID = NA, 
  alpha.fisher = 2, 
  nu = 1e-04, 
  speciation.limit = NA, 
  n.timestep = 10, 
  landscape.edge.size = 5, 
  ave.JL = 200, 
  JL.min.proportion = 1,         
  target.m = 0.25, 
  IL.scale = NA, 
  JL.scale = NA, 
  Ef.scale = NA, 
  Ef.specificity = 0,
  Ef.specificity.scale = NA,
  SWM.slope = 0, 
  trait.dispersal.median = 1, 
  trait.dispersal.range = 0, 
  trait.Ef.sd = 0.1, q.order = c(0,2), 
  save.sim = TRUE, 
  output.dir.path = "SIM_OUTPUT", 
  keep.timesteps = c(1, 10)
  ){
  n.sites <- landscape.edge.size^2
  JM <- n.sites * ave.JL
  JL.min <- JL.min.proportion * ave.JL
  JL.min <- ifelse(JL.min < 1, 1, JL.min)
  IL.intensity <- round((target.m * (ave.JL - 1))/(1 - target.m), 
                        0)
  landscape <- fn.make.landscape(JM = JM, n.sites = n.sites, 
                                 JL.scale = JL.scale, 
                                  Ef.scale = Ef.scale, 
                                  Ef.specificity = Ef.specificity,
                                  Ef.specificity.scale=Ef.specificity.scale,
                                 IL.scale = IL.scale, IL.intensity = IL.intensity, JL.min)
  dat.gamma.t0 <- fn.set.regional.species.pool(n.timestep = n.timestep, 
                                               nu = nu, speciation.limit = speciation.limit, JM = JM, 
                                               alpha.fisher = alpha.fisher, trait.dispersal.median = trait.dispersal.median, 
                                               trait.dispersal.range = trait.dispersal.range)
  taxa.list <- as.character(dat.gamma.t0$taxa.list)
  d.temp <- expand.grid(Ef = landscape$dat$Ef, stringsAsFactors = FALSE, 
                        trait.Ef = dat.gamma.t0$trait.Ef)
  d.temp$Ef.specificity <- landscape$dat$Ef.specificity
  lambda.Ef.siteBYspp <- matrix(data = mapply(FUN = fn.lambda, 
                                              trait.optimum = d.temp$trait.Ef, Ef = d.temp$Ef, Ef.specificity = d.temp$Ef.specificity, 
                                              MoreArgs = list(niche.breadth = trait.Ef.sd)), nrow = nrow(landscape$dat), 
                                ncol = length(taxa.list), byrow = FALSE)
  lambda.Ef.siteBYspp <- lambda.Ef.siteBYspp/rowSums(lambda.Ef.siteBYspp)
  n.sites <- nrow(landscape$dat)
  R.probs.t0 <- lambda.Ef.siteBYspp * (rep(1, n.sites) %o% 
                                         dat.gamma.t0$regional.RA)
  R.probs.t0 <- R.probs.t0/rowSums(R.probs.t0)
  R.probs.list <- as.list(data.frame(t(R.probs.t0)))
  J.t0 <- data.frame(row.names = NULL, t(mapply(FUN = fn.lottery.recruit, 
                                                vect.recruitment.weights = R.probs.list, scalar.JL = as.list(landscape$dat$JL), 
                                                MoreArgs = list(vect.taxa.list = taxa.list))))
  J <- list()
  J[[1]] <- J.t0
  J.t.minus.1 <- J.t0
  for (t.index in 2:n.timestep) {
    J.t <- fn.recruit.Jt(landscape.xy = landscape$dat[, c("x", 
                                                          "y")], nu = nu, SWM.slope = SWM.slope, J.t.minus.1 = J.t.minus.1, 
                         taxa.list = taxa.list, traits.Ef = dat.gamma.t0$trait.Ef, 
                         trait.Ef.sd = trait.Ef.sd, traits.dispersal = dat.gamma.t0$trait.dispersal, 
                         landscape.m = landscape$dat$m, landscape.Ef = landscape$dat$Ef, 
                         landscape.Ef.specificity = landscape$dat$Ef.specificity, 
                         landscape.JL = landscape$dat$JL)
    J[[t.index]] <- J.t
    J.t.minus.1 <- J.t
    print(paste("Timestep:", t.index))
  }
  sim.result.name <- paste("SIM_", scenario.ID, "_", format(Sys.time(), 
                                                            "%Y%m%d_%H%M%S"), "_", trunc(runif(1, 1e+05, 999999)), 
                           sep = "")
  sim.result <- list(scenario.ID = scenario.ID, sim.result.name = sim.result.name, 
                     x = landscape$dat$x, y = landscape$dat$y, JL = landscape$dat$JL, 
                     Ef = landscape$dat$Ef, Ef.specificity = Ef.specificity, 
                     m = landscape$dat$m, alpha.fisher = alpha.fisher, nu.sim = nu, 
                     trait.Ef.sd = trait.Ef.sd, trait.dispersal = dat.gamma.t0$trait.dispersal, 
                     trait.Ef = dat.gamma.t0$trait.Ef, landscape = landscape, 
                     dat.gamma.t0 = dat.gamma.t0, SWM.slope = SWM.slope, J = J, 
                     n.timestep = n.timestep, taxa.list = taxa.list)
  fn.sim.metadata.archive4(sim.result = sim.result, q.order = q.order, 
                           save.sim = save.sim, var.dir = output.dir.path, 
                           keep.timesteps = keep.timesteps)
  return(sim.result)
}