is.count <-
function(a){
  inherits(a, "count")
}
