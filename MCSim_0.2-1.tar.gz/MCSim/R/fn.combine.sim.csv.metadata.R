fn.combine.sim.csv.metadata <-
function(
  out.dir.name=out.dir.name,
  file.name="sim.metadata_",
  n.sims=nrow(data.simparameters)){
  require(plyr)
  if((length(n.sims)==1)&(is.numeric(n.sims))){
	scenario.list<-c(1:n.sims)
  }else{
	scenario.list<-n.sims
  }
  dat.list<-alply(
    .data=scenario.list,
    .margins=1,
    .fun=function(i.sim,out.dir.name,file.name){
      filename.temp<-paste(out.dir.name,"/",file.name,i.sim,".csv",sep="")
      if(file.exists(filename.temp)){
        return(read.csv(file=filename.temp,
                        stringsAsFactors=FALSE,row.names=1))
      }else{
        return("no sim output")
      }
    },
    out.dir.name=out.dir.name,
    file.name=file.name)
  
  expected.cols<-max(unlist(lapply(dat.list,length)))
  
  if(expected.cols>0){
    dat.list.keepers<-dat.list[lapply(dat.list,length)==expected.cols]
    dat.all<-do.call(rbind,dat.list.keepers)
    write.csv(dat.all,file=paste(out.dir.name,"/sim.metadata.csv",sep=""))
  }else{
    print("warning: no metadata or results")
  }
}
