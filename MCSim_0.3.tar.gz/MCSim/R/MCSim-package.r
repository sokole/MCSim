#' MCSim.
#'
#' @name MCSim
#' @docType package
NULL
