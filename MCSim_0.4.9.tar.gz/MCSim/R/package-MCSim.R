#' MCSim: A metacommunity simulation package
#' 
#' The MCSim package provides functions necessary for running iterative, lottery-based metacommunity simulations
#' 
#' @docType package
#' @name MCSim
NULL
